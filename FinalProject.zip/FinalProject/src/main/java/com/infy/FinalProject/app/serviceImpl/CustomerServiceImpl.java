package com.infy.FinalProject.app.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.infy.FinalProject.app.Service.CustomerService;
import com.infy.FinalProject.app.model.Customer;
import com.infy.FinalProject.app.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
    CustomerRepository cr;


	@Override
	public Customer savecustomer(Customer cc) {
	
		return cr.save(cc);
	}
	
	
}
