package com.infy.FinalProject.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.FinalProject.app.model.EMi;


@Repository

public interface EMiRepository  extends JpaRepository<EMi, Integer>{



}
