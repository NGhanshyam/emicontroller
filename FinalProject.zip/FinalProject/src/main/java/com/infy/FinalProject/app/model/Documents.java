package com.infy.FinalProject.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Documents {
	@Id
	private int did;
	private byte[] adhar;
	private byte[] pan;
	private byte[] propdoc;
	private byte[] electricbill;
	private byte[] photo;
	private byte[] sign;
	private byte[] groupdoc;
	private byte[] gstamt;
	private byte[] cheque;
	
	

}
