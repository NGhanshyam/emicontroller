package com.infy.FinalProject.app.Service;

import com.infy.FinalProject.app.model.Cibil;

public interface CibilIService {

	int regCibilScore(Cibil cibil);

}
