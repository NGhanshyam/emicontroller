package com.infy.FinalProject.app.Service;

import com.infy.FinalProject.app.model.EMi;

public interface EMiService {

	EMi saveEmi(EMi e);


}
