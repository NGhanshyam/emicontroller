package com.infy.FinalProject.app.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.FinalProject.app.Service.CibilIService;
import com.infy.FinalProject.app.model.Cibil;

@RestController
@RequestMapping ("/cibil")
public class CibilController {
	@Autowired
	CibilIService cis;
	
	@PostMapping("/saveCibil")
	public int regCibilScore(@RequestBody Cibil cibil)
	{
		System.out.println(cibil.getCibilScore());
		int c = cis.regCibilScore(cibil);
		
		return c;
	}
}
