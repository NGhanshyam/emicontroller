package com.infy.FinalProject.app.Service;

import com.infy.FinalProject.app.model.Customer;

public interface CustomerService {

public 	Customer savecustomer(Customer cc);


}
