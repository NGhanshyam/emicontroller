
package com.infy.FinalProject.app.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.FinalProject.app.Service.EMiService;
import com.infy.FinalProject.app.model.EMi;
import com.infy.FinalProject.app.repository.EMiRepository;


@Service
public class EMIServiceImpl implements EMiService{
	@Autowired
    EMiRepository er;

	@Override
	public EMi saveEmi(EMi e) {
		return er.save(e);
	}

	
	

}
