package com.infy.FinalProject.app.serviceImpl;

import org.springframework.stereotype.Service;

import com.infy.FinalProject.app.Service.SanctionLetterIService;
@Service
public class SanctionServiceImpl implements SanctionLetterIService{

}
