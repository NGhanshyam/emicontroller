package com.infy.FinalProject.app.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infy.FinalProject.app.Service.EMiService;
import com.infy.FinalProject.app.model.EMi;



@RestController
public class EMiController {
	 @Autowired
	 EMiService es;
	 
	@PostMapping(value="/saveemi")
	public int saveemi(@RequestBody EMi e)
	{ 
	 int outstandingAmount=e.getLoanAmount() +(e.getLoanAmount() * (e.getInterest() / 100) * e.getTenure());
     int emi = outstandingAmount /e.getTenure();
	  e.setEmi(emi);
	  EMi em=es.saveEmi(e);
		return em.getEmi();
	}

}
