package com.infy.FinalProject.app.Service;

public interface ApplicantIService {

}
